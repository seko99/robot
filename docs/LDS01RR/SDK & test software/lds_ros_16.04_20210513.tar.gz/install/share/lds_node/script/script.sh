
echo "begin to install usb drive!!"

sudo cp 'rospack find lds_node'/../../lds_node/script/20-lds-usb.rules /etc/udev/rules.d/

sudo udevadm control --reload
echo "install done!!!"
